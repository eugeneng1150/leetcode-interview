// src/lib/editor-content.ts
function extractEditorSnapshot(doc, win = window) {
  const fromMonaco = readFromMonacoModel(win);
  if (fromMonaco) {
    return fromMonaco;
  }
  const fromTextarea = readFromEditorTextarea(doc);
  if (fromTextarea) {
    return fromTextarea;
  }
  const fromCodeBlock = readFromCodeBlock(doc);
  if (fromCodeBlock) {
    return fromCodeBlock;
  }
  const fromVisibleLines = readFromVisibleEditorLines(doc);
  if (fromVisibleLines) {
    return fromVisibleLines;
  }
  return null;
}
function readFromMonacoModel(win) {
  const monaco = win.monaco;
  const models = monaco?.editor?.getModels?.();
  if (!Array.isArray(models) || models.length === 0) {
    return null;
  }
  for (const model of models) {
    const value = model?.getValue?.().trim();
    if (looksLikeCode(value)) {
      return {
        code: value,
        source: "monaco-model"
      };
    }
  }
  return null;
}
function readFromEditorTextarea(doc) {
  const selectors = [
    "textarea[data-mode-id]",
    ".monaco-editor textarea",
    "textarea.inputarea",
    "textarea[spellcheck='false']",
    "textarea"
  ];
  for (const selector of selectors) {
    const candidates = Array.from(doc.querySelectorAll(selector));
    for (const textarea of candidates) {
      const value = textarea.value.trim();
      if (looksLikeCode(value)) {
        return {
          code: value,
          source: "textarea"
        };
      }
    }
  }
  return null;
}
function readFromCodeBlock(doc) {
  const selectors = [
    "[data-track-load='code_editor'] pre",
    "[data-track-load='code_editor'] code",
    "[class*='code-area'] pre",
    "[class*='editor'] pre",
    "[class*='editor'] code"
  ];
  for (const selector of selectors) {
    const blocks = Array.from(doc.querySelectorAll(selector));
    for (const block of blocks) {
      const value = normalizeCodeText(block.innerText || block.textContent || "");
      if (looksLikeCode(value)) {
        return {
          code: value,
          source: "code-block"
        };
      }
    }
  }
  return null;
}
function readFromVisibleEditorLines(doc) {
  const containers = Array.from(doc.querySelectorAll(".monaco-editor .view-lines"));
  for (const container of containers) {
    const lines = Array.from(container.querySelectorAll(".view-line")).map((line) => normalizeCodeText(line.innerText || line.textContent || "")).filter(Boolean);
    if (lines.length === 0) {
      continue;
    }
    const value = lines.join("\n").trim();
    if (looksLikeCode(value)) {
      return {
        code: value,
        source: "visible-lines"
      };
    }
  }
  return null;
}
function looksLikeCode(value) {
  if (!value) {
    return false;
  }
  const text = value.trim();
  if (text.length < 8) {
    return false;
  }
  return text.includes("\n") || /[{}();=<>]/.test(text) || /\b(function|class|const|let|var|def|public|private|return|if|for|while)\b/.test(text);
}
function normalizeCodeText(value) {
  return value.replace(/\u00a0/g, " ").replace(/\r\n/g, "\n").trim();
}

// src/lib/page-distractions.ts
var HIDE_ATTRIBUTE = "data-leetcode-interviewer-hidden";
var HIDE_VISIBILITY_ATTRIBUTE = "data-leetcode-interviewer-visibility";
var SOLUTION_LABELS = /* @__PURE__ */ new Set(["solution", "solutions", "editorial"]);
var DISCUSSION_LABELS = /* @__PURE__ */ new Set(["discussion", "discussions", "discuss"]);
function setDistractionSectionsHidden(doc, hidden) {
  const targets = collectDistractionTargets(doc);
  for (const element of targets) {
    if (hidden) {
      hideElement(element);
    } else {
      showElement(element);
    }
  }
  return {
    count: targets.length,
    hidden
  };
}
function collectDistractionTargets(doc) {
  const targets = /* @__PURE__ */ new Set();
  const interactiveCandidates = Array.from(
    doc.querySelectorAll("[role='tab'], [aria-controls], button, a, h2, h3, h4")
  );
  for (const element of interactiveCandidates) {
    const label = normalizeText(element.textContent);
    if (!label) {
      continue;
    }
    if (!matchesDistraction(label) && !matchesDistractionHref(element)) {
      continue;
    }
    targets.add(element);
    addContainerTargets(element, targets);
    const controlsId = element.getAttribute("aria-controls");
    if (controlsId) {
      const controlled = doc.getElementById(controlsId);
      if (controlled instanceof HTMLElement) {
        targets.add(controlled);
        addContainerTargets(controlled, targets);
      }
    }
    const tabPanel = element.closest("[role='tabpanel']");
    if (tabPanel) {
      targets.add(tabPanel);
      addContainerTargets(tabPanel, targets);
    }
  }
  return Array.from(targets);
}
function matchesDistraction(label) {
  return SOLUTION_LABELS.has(label) || DISCUSSION_LABELS.has(label);
}
function matchesDistractionHref(element) {
  if (!(element instanceof HTMLAnchorElement)) {
    return false;
  }
  const href = element.href.toLowerCase();
  return href.includes("/solutions") || href.includes("/discuss") || href.includes("/discussion");
}
function normalizeText(value) {
  return value?.trim().toLowerCase() ?? "";
}
function hideElement(element) {
  if (!element.hasAttribute(HIDE_ATTRIBUTE)) {
    element.setAttribute(HIDE_ATTRIBUTE, element.style.display || "");
  }
  if (!element.hasAttribute(HIDE_VISIBILITY_ATTRIBUTE)) {
    element.setAttribute(HIDE_VISIBILITY_ATTRIBUTE, element.style.visibility || "");
  }
  element.style.display = "none";
  element.style.visibility = "hidden";
}
function showElement(element) {
  if (!element.hasAttribute(HIDE_ATTRIBUTE)) {
    return;
  }
  const previousDisplay = element.getAttribute(HIDE_ATTRIBUTE) ?? "";
  const previousVisibility = element.getAttribute(HIDE_VISIBILITY_ATTRIBUTE) ?? "";
  element.style.display = previousDisplay;
  element.style.visibility = previousVisibility;
  element.removeAttribute(HIDE_ATTRIBUTE);
  element.removeAttribute(HIDE_VISIBILITY_ATTRIBUTE);
}
function addContainerTargets(element, targets) {
  const container = findHideContainer(element);
  if (container) {
    targets.add(container);
  }
}
function findHideContainer(element) {
  const candidates = [
    element.closest("section"),
    element.closest("article"),
    element.closest("[role='tabpanel']"),
    element.closest("[data-layout-path]"),
    element.closest("div[class*='panel']"),
    element.closest("div[class*='card']")
  ].filter((candidate) => candidate instanceof HTMLElement);
  for (const candidate of candidates) {
    if (!candidate.textContent) {
      continue;
    }
    const textLength = candidate.textContent.trim().length;
    if (textLength >= 20 && textLength <= 4e3) {
      return candidate;
    }
  }
  return null;
}

// src/lib/api-client.ts
var ApiClientError = class extends Error {
  code;
  constructor(code, message) {
    super(message);
    this.name = "ApiClientError";
    this.code = code;
  }
};
async function requestHint(input, onProgress) {
  const port = chrome.runtime.connect({
    name: "hint-stream"
  });
  return new Promise((resolve, reject) => {
    let settled = false;
    const cleanup = () => {
      if (settled) {
        return;
      }
      settled = true;
      port.onMessage.removeListener(handleMessage);
      port.onDisconnect.removeListener(handleDisconnect);
      port.disconnect();
    };
    const handleDisconnect = () => {
      if (settled) {
        return;
      }
      cleanup();
      reject(new ApiClientError("HINT_STREAM_DISCONNECTED", "Hint stream disconnected unexpectedly."));
    };
    const handleMessage = (message) => {
      if (!isHintStreamEvent(message)) {
        cleanup();
        reject(new ApiClientError("INVALID_API_RESPONSE", "Hint stream response was malformed."));
        return;
      }
      if (message.type === "hint_delta") {
        onProgress?.(message.hint);
        return;
      }
      if (message.type === "completed") {
        cleanup();
        resolve(message.data);
        return;
      }
      cleanup();
      reject(new ApiClientError(message.error.code, message.error.message));
    };
    port.onMessage.addListener(handleMessage);
    port.onDisconnect.addListener(handleDisconnect);
    port.postMessage({
      kind: "start",
      payload: input
    });
  });
}
async function requestReview(input) {
  const payload = await sendApiMessage("review", input);
  if (!isReviewResponse(payload)) {
    throw new ApiClientError("INVALID_API_RESPONSE", "Review response was malformed.");
  }
  return payload;
}
async function loadAssistantSettings() {
  const payload = await sendApiMessage("settings:get");
  if (!isAssistantSettingsSummary(payload)) {
    throw new ApiClientError("INVALID_BACKGROUND_RESPONSE", "Assistant settings response was malformed.");
  }
  return payload;
}
async function saveAssistantSettings(input) {
  const payload = await sendApiMessage("settings:save", input);
  if (!isAssistantSettingsSummary(payload)) {
    throw new ApiClientError("INVALID_BACKGROUND_RESPONSE", "Assistant settings response was malformed.");
  }
  return payload;
}
async function clearAssistantSettings() {
  const payload = await sendApiMessage("settings:clear");
  if (!isAssistantSettingsSummary(payload)) {
    throw new ApiClientError("INVALID_BACKGROUND_RESPONSE", "Assistant settings response was malformed.");
  }
  return payload;
}
async function testAssistantConnection() {
  const payload = await sendApiMessage("settings:test");
  if (!isAssistantConnectionStatus(payload)) {
    throw new ApiClientError("INVALID_BACKGROUND_RESPONSE", "Assistant connection response was malformed.");
  }
  return payload;
}
async function sendApiMessage(kind, payload) {
  const response = await chrome.runtime.sendMessage({
    kind,
    payload
  });
  if (!isRuntimeResponse(response)) {
    throw new ApiClientError(
      "INVALID_BACKGROUND_RESPONSE",
      "Extension background service returned an invalid response."
    );
  }
  if (!response.ok) {
    throw new ApiClientError(response.error.code, response.error.message);
  }
  return response.data;
}
function isHintResponse(value) {
  if (!isRecord(value)) {
    return false;
  }
  return typeof value.hint === "string" && typeof value.followUpQuestion === "string";
}
function isHintStreamEvent(value) {
  if (!isRecord(value) || typeof value.type !== "string") {
    return false;
  }
  switch (value.type) {
    case "hint_delta":
      return typeof value.delta === "string" && typeof value.hint === "string";
    case "completed":
      return "data" in value && isHintResponse(value.data);
    case "error":
      return "error" in value && isApiError(value.error);
    default:
      return false;
  }
}
function isReviewResponse(value) {
  if (!isRecord(value)) {
    return false;
  }
  return typeof value.clarityFeedback === "string" && typeof value.timeComplexity === "string" && typeof value.spaceComplexity === "string" && typeof value.improvementSuggestion === "string";
}
function isAssistantSettingsSummary(value) {
  if (!isRecord(value)) {
    return false;
  }
  return typeof value.hasApiKey === "boolean" && (typeof value.apiKeyLabel === "string" || value.apiKeyLabel === null) && typeof value.model === "string";
}
function isAssistantConnectionStatus(value) {
  if (!isRecord(value)) {
    return false;
  }
  return typeof value.configured === "boolean" && typeof value.ok === "boolean" && typeof value.message === "string" && typeof value.model === "string";
}
function isRuntimeResponse(value) {
  if (!isRecord(value) || typeof value.ok !== "boolean") {
    return false;
  }
  if (value.ok) {
    return "data" in value;
  }
  return "error" in value && isApiError(value.error);
}
function isApiError(value) {
  if (!isRecord(value)) {
    return false;
  }
  return typeof value.code === "string" && typeof value.message === "string";
}
function isRecord(value) {
  return typeof value === "object" && value !== null;
}

// src/lib/problem-page.ts
function isSupportedProblemPage(url) {
  return /^\/problems\/[^/]+(?:\/description)?\/?$/.test(url.pathname);
}
function extractProblemContext(doc, url) {
  const title = readProblemTitle(doc, url);
  const description = readProblemDescription(doc);
  const difficultyText = readDifficulty(doc);
  if (!title || !description) {
    return null;
  }
  return {
    problemTitle: normalizeProblemTitle(title),
    problemDescription: description,
    problemUrl: normalizeProblemUrl(url),
    difficulty: normalizeDifficulty(difficultyText)
  };
}
function normalizeProblemUrl(url) {
  const normalized = new URL(url.toString());
  normalized.search = "";
  normalized.hash = "";
  const pathname = normalized.pathname.replace(/\/+$/, "");
  normalized.pathname = pathname.endsWith("/description") ? pathname.slice(0, -"/description".length) || "/" : pathname || "/";
  return normalized.toString();
}
function normalizeProblemTitle(value) {
  return value.replace(/^\d+\.\s*/, "").trim();
}
function normalizeDifficulty(value) {
  if (!value) {
    return null;
  }
  const normalized = value.trim();
  if (normalized === "Easy" || normalized === "Medium" || normalized === "Hard") {
    return normalized;
  }
  if (normalized.includes("Easy")) {
    return "Easy";
  }
  if (normalized.includes("Medium")) {
    return "Medium";
  }
  if (normalized.includes("Hard")) {
    return "Hard";
  }
  return null;
}
function readProblemTitle(doc, url) {
  const title = firstText(doc, [
    "[data-cy='question-title']",
    ".text-title-large",
    "a[href^='/problems/'][class*='truncate']",
    "main h1",
    "h1"
  ]);
  if (title) {
    return title;
  }
  const slug = url.pathname.match(/^\/problems\/([^/]+)/)?.[1];
  if (!slug) {
    return null;
  }
  return slug.split("-").filter(Boolean).map((part) => part.charAt(0).toUpperCase() + part.slice(1)).join(" ");
}
function readProblemDescription(doc) {
  const targeted = firstText(doc, [
    "[data-track-load='description_content']",
    "[data-key='description-content']",
    "[data-cy='question-content']",
    "article"
  ]);
  if (looksLikeProblemDescription(targeted)) {
    return sanitizeDescription(targeted ?? "");
  }
  const marker = findDescriptionMarker(doc);
  if (!marker) {
    return null;
  }
  const container = marker.closest("article, section, div");
  const candidate = container?.textContent?.trim() ?? marker.textContent?.trim() ?? "";
  return looksLikeProblemDescription(candidate) ? sanitizeDescription(candidate) : null;
}
function readDifficulty(doc) {
  const targeted = firstText(doc, ["[diff]", "[class*='difficulty']", "main"]);
  if (!targeted) {
    return null;
  }
  const match = targeted.match(/\b(Easy|Medium|Hard)\b/);
  return match?.[1] ?? null;
}
function firstText(doc, selectors) {
  for (const selector of selectors) {
    const text = doc.querySelector(selector)?.textContent?.trim();
    if (text) {
      return text;
    }
  }
  return null;
}
function findDescriptionMarker(doc) {
  const candidates = Array.from(doc.querySelectorAll("p, div, section, article, pre"));
  for (const candidate of candidates) {
    const text = candidate.textContent?.trim() ?? "";
    if (text.length < 20) {
      continue;
    }
    if (text.includes("Example 1") || text.includes("Constraints") || text.includes("Input:") || text.includes("Output:")) {
      return candidate;
    }
  }
  return null;
}
function looksLikeProblemDescription(value) {
  if (!value) {
    return false;
  }
  const text = value.trim();
  if (text.length < 120) {
    return false;
  }
  return text.includes("Example") || text.includes("Constraints") || text.includes("Input:") || text.includes("Output:");
}
function sanitizeDescription(value) {
  return value.replace(/\s+/g, " ").trim();
}

// src/lib/session-storage.ts
var SESSION_KEY = "leetcode-interviewer:last-session";
var SESSION_HISTORY_KEY = "leetcode-interviewer:session-history";
var NOTES_KEY_PREFIX = "leetcode-interviewer:notes:";
var MAX_SESSION_HISTORY = 8;
async function saveSessionSummary(summary) {
  const history = await loadSessionHistory();
  const nextHistory = [
    summary,
    ...history.filter(
      (entry) => !(entry.problemUrl === summary.problemUrl && entry.startedAt === summary.startedAt)
    )
  ].slice(0, MAX_SESSION_HISTORY);
  await chrome.storage?.local?.set?.({
    [SESSION_KEY]: summary,
    [SESSION_HISTORY_KEY]: nextHistory
  });
}
async function loadLastSessionSummary() {
  const result = await chrome.storage?.local?.get?.(SESSION_KEY);
  return result?.[SESSION_KEY] ?? null;
}
async function loadSessionHistory() {
  const result = await chrome.storage?.local?.get?.(SESSION_HISTORY_KEY);
  const history = result?.[SESSION_HISTORY_KEY];
  return Array.isArray(history) ? history : [];
}
async function saveProblemNotes(problemUrl, notes) {
  await chrome.storage?.local?.set?.({
    [getNotesKey(problemUrl)]: notes
  });
}
async function loadProblemNotes(problemUrl) {
  const result = await chrome.storage?.local?.get?.(getNotesKey(problemUrl));
  return result?.[getNotesKey(problemUrl)] ?? "";
}
async function clearLocalData() {
  const result = await chrome.storage?.local?.get?.(null);
  const keys = Object.keys(result ?? {}).filter(
    (key) => key === SESSION_KEY || key === SESSION_HISTORY_KEY || key.startsWith(NOTES_KEY_PREFIX)
  );
  if (keys.length === 0) {
    return;
  }
  await chrome.storage?.local?.remove?.(keys);
}
function getNotesKey(problemUrl) {
  return `${NOTES_KEY_PREFIX}${problemUrl}`;
}

// src/panel/index.ts
function createInterviewPanel(container, options) {
  const root = document.createElement("aside");
  root.dataset.role = "interview-panel";
  root.style.position = "fixed";
  root.style.top = "20px";
  root.style.right = "20px";
  root.style.width = "360px";
  root.style.maxHeight = "calc(100vh - 40px)";
  root.style.overflow = "auto";
  root.style.zIndex = "2147483647";
  root.style.padding = "18px";
  root.style.borderRadius = "20px";
  root.style.background = "linear-gradient(180deg, #fcfbf7 0%, #f3efe4 100%)";
  root.style.color = "#1f2937";
  root.style.border = "1px solid rgba(180, 157, 104, 0.35)";
  root.style.boxShadow = "0 24px 50px rgba(15, 23, 42, 0.18)";
  root.style.fontFamily = "Georgia, 'Times New Roman', serif";
  root.style.transition = "width 180ms ease, padding 180ms ease";
  const header = document.createElement("div");
  header.style.display = "flex";
  header.style.alignItems = "flex-start";
  header.style.justifyContent = "space-between";
  header.style.gap = "12px";
  header.style.marginBottom = "14px";
  header.style.cursor = "grab";
  header.style.touchAction = "none";
  const titleGroup = document.createElement("div");
  titleGroup.style.minWidth = "0";
  const title = document.createElement("h2");
  title.textContent = "Interview Mode";
  title.style.margin = "0 0 4px";
  title.style.fontSize = "28px";
  title.style.lineHeight = "1.1";
  title.style.color = "#111827";
  title.style.fontWeight = "700";
  title.style.textShadow = "0 1px 0 rgba(255, 255, 255, 0.35)";
  const problem = document.createElement("p");
  problem.textContent = options.context.problemTitle;
  problem.style.margin = "0";
  problem.style.color = "#475467";
  problem.style.fontFamily = "ui-sans-serif, system-ui, sans-serif";
  problem.style.fontSize = "13px";
  problem.style.lineHeight = "1.4";
  titleGroup.append(title, problem);
  const collapseButton = createButton("Collapse", "secondary");
  collapseButton.style.padding = "10px 12px";
  collapseButton.style.flexShrink = "0";
  collapseButton.style.minWidth = "90px";
  header.append(titleGroup, collapseButton);
  const body = document.createElement("div");
  const collapsedSummary = createCard();
  collapsedSummary.style.display = "none";
  collapsedSummary.style.padding = "10px 12px";
  const collapsedMode = createMetaLabel("Mode");
  const collapsedModeValue = document.createElement("p");
  collapsedModeValue.style.margin = "6px 0 0";
  collapsedModeValue.style.fontFamily = "ui-sans-serif, system-ui, sans-serif";
  collapsedModeValue.style.fontSize = "12px";
  collapsedModeValue.style.fontWeight = "700";
  const collapsedTimer = document.createElement("p");
  collapsedTimer.style.margin = "10px 0 0";
  collapsedTimer.style.fontFamily = "ui-sans-serif, system-ui, sans-serif";
  collapsedTimer.style.fontSize = "20px";
  collapsedTimer.style.fontWeight = "700";
  const collapsedHints = document.createElement("p");
  collapsedHints.style.margin = "8px 0 0";
  collapsedHints.style.fontFamily = "ui-sans-serif, system-ui, sans-serif";
  collapsedHints.style.fontSize = "12px";
  collapsedHints.style.lineHeight = "1.4";
  collapsedHints.style.color = "#667085";
  collapsedSummary.append(collapsedMode, collapsedModeValue, collapsedTimer, collapsedHints);
  const modeCard = createCard();
  modeCard.style.marginBottom = "14px";
  const modeLabel = createMetaLabel("Mode");
  const modeValue = document.createElement("p");
  modeValue.textContent = "Off";
  modeValue.style.margin = "6px 0 0";
  modeValue.style.fontFamily = "ui-sans-serif, system-ui, sans-serif";
  modeValue.style.fontWeight = "700";
  modeValue.style.fontSize = "16px";
  modeCard.append(modeLabel, modeValue);
  const controls = document.createElement("div");
  controls.style.display = "grid";
  controls.style.gridTemplateColumns = "1fr 1fr";
  controls.style.gap = "8px";
  controls.style.marginBottom = "14px";
  const startButton = createButton("Start Interview", "primary");
  const distractionButton = createButton("Hide Distractions", "secondary");
  distractionButton.disabled = true;
  controls.append(startButton, distractionButton);
  const settingsCard = createCard();
  settingsCard.style.marginBottom = "14px";
  const settingsLabel = createMetaLabel("OpenAI Setup");
  const settingsSummary = document.createElement("p");
  settingsSummary.style.margin = "6px 0 0";
  settingsSummary.style.fontFamily = "ui-sans-serif, system-ui, sans-serif";
  settingsSummary.style.fontSize = "13px";
  settingsSummary.style.lineHeight = "1.5";
  settingsSummary.style.color = "#475467";
  settingsSummary.textContent = "No API key saved yet.";
  const settingsHelper = document.createElement("p");
  settingsHelper.textContent = "Your key stays in this Chrome profile. It is used directly for hint and review requests.";
  settingsHelper.style.margin = "8px 0 0";
  settingsHelper.style.fontFamily = "ui-sans-serif, system-ui, sans-serif";
  settingsHelper.style.fontSize = "12px";
  settingsHelper.style.lineHeight = "1.5";
  settingsHelper.style.color = "#667085";
  const apiKeyInput = createTextInput("password", "Paste your OpenAI API key");
  apiKeyInput.style.marginTop = "10px";
  apiKeyInput.autocomplete = "off";
  apiKeyInput.spellcheck = false;
  const modelInput = createTextInput("text", "gpt-4.1-mini");
  modelInput.style.marginTop = "8px";
  const settingsButtons = document.createElement("div");
  settingsButtons.style.display = "grid";
  settingsButtons.style.gridTemplateColumns = "1fr 1fr 1fr";
  settingsButtons.style.gap = "8px";
  settingsButtons.style.marginTop = "10px";
  const saveSettingsButton = createButton("Save", "secondary");
  const testSettingsButton = createButton("Test", "secondary");
  const clearSettingsButton = createButton("Clear", "secondary");
  settingsButtons.append(saveSettingsButton, testSettingsButton, clearSettingsButton);
  const settingsStatus = document.createElement("p");
  settingsStatus.textContent = "Save your API key to enable hints and review.";
  settingsStatus.style.margin = "10px 0 0";
  settingsStatus.style.fontFamily = "ui-sans-serif, system-ui, sans-serif";
  settingsStatus.style.fontSize = "12px";
  settingsStatus.style.lineHeight = "1.5";
  settingsStatus.style.color = "#475467";
  settingsCard.append(
    settingsLabel,
    settingsSummary,
    settingsHelper,
    apiKeyInput,
    modelInput,
    settingsButtons,
    settingsStatus
  );
  const timerCard = createCard();
  timerCard.style.marginBottom = "14px";
  const timerLabel = createMetaLabel("Session Timer");
  const timer = document.createElement("p");
  timer.textContent = "00:00";
  timer.style.margin = "4px 0 0";
  timer.style.fontSize = "30px";
  timer.style.fontWeight = "700";
  timer.style.fontFamily = "ui-sans-serif, system-ui, sans-serif";
  timerCard.append(timerLabel, timer);
  const hintUsageCard = createCard();
  hintUsageCard.style.marginBottom = "14px";
  const hintUsageLabel = createMetaLabel("Hint Progress");
  const hintUsageValue = document.createElement("p");
  hintUsageValue.style.margin = "4px 0 0";
  hintUsageValue.style.fontFamily = "ui-sans-serif, system-ui, sans-serif";
  hintUsageValue.style.fontWeight = "600";
  const hintUsageMeta = document.createElement("p");
  hintUsageMeta.style.margin = "8px 0 0";
  hintUsageMeta.style.fontFamily = "ui-sans-serif, system-ui, sans-serif";
  hintUsageMeta.style.fontSize = "12px";
  hintUsageMeta.style.lineHeight = "1.4";
  hintUsageMeta.style.color = "#667085";
  hintUsageMeta.textContent = "Hints are unlimited. Level 1 nudges, Level 2 patterns, Level 3+ stronger direction.";
  hintUsageCard.append(hintUsageLabel, hintUsageValue, hintUsageMeta);
  const notesLabel = createMetaLabel("Talk Through Your Approach");
  notesLabel.style.marginBottom = "8px";
  const notes = document.createElement("textarea");
  notes.placeholder = "Talk through your approach...";
  notes.rows = 7;
  notes.style.width = "100%";
  notes.style.boxSizing = "border-box";
  notes.style.border = "1px solid #d0d5dd";
  notes.style.borderRadius = "14px";
  notes.style.padding = "12px";
  notes.style.fontFamily = "ui-sans-serif, system-ui, sans-serif";
  notes.style.fontSize = "14px";
  notes.style.background = "rgba(255, 255, 255, 0.88)";
  notes.style.marginBottom = "14px";
  notes.disabled = true;
  const notesMeta = document.createElement("p");
  notesMeta.textContent = "Notes save automatically for this problem.";
  notesMeta.style.margin = "-6px 0 14px";
  notesMeta.style.fontFamily = "ui-sans-serif, system-ui, sans-serif";
  notesMeta.style.fontSize = "12px";
  notesMeta.style.color = "#667085";
  const actions = document.createElement("div");
  actions.style.display = "grid";
  actions.style.gridTemplateColumns = "1fr 1fr";
  actions.style.gap = "8px";
  actions.style.marginBottom = "14px";
  const hintButton = createButton(`Get Hint`, "secondary");
  const reviewButton = createButton("Review My Attempt", "secondary");
  hintButton.disabled = true;
  reviewButton.disabled = true;
  actions.append(hintButton, reviewButton);
  const hintCard = createCard();
  hintCard.style.marginBottom = "14px";
  const hintLabel = createMetaLabel("Latest Hint");
  const hintText = document.createElement("p");
  hintText.textContent = "Start the session to unlock hints.";
  hintText.style.margin = "6px 0 0";
  hintText.style.fontFamily = "ui-sans-serif, system-ui, sans-serif";
  hintText.style.fontSize = "13px";
  hintText.style.lineHeight = "1.5";
  const followUp = document.createElement("p");
  followUp.style.margin = "8px 0 0";
  followUp.style.color = "#667085";
  followUp.style.fontFamily = "ui-sans-serif, system-ui, sans-serif";
  followUp.style.fontSize = "12px";
  hintCard.append(hintLabel, hintText, followUp);
  const reviewCard = createCard();
  reviewCard.style.marginBottom = "14px";
  const reviewLabel = createMetaLabel("Basic Review");
  const reviewText = document.createElement("p");
  reviewText.textContent = "No review yet.";
  reviewText.style.margin = "6px 0 0";
  reviewText.style.fontFamily = "ui-sans-serif, system-ui, sans-serif";
  reviewText.style.fontSize = "13px";
  reviewText.style.lineHeight = "1.5";
  reviewCard.append(reviewLabel, reviewText);
  const recentSessionsCard = createCard();
  recentSessionsCard.style.marginBottom = "14px";
  const recentSessionsLabel = createMetaLabel("Recent Sessions");
  const recentSessionsList = document.createElement("div");
  recentSessionsList.style.marginTop = "8px";
  recentSessionsCard.append(recentSessionsLabel, recentSessionsList);
  const lastSessionCard = createCard();
  lastSessionCard.style.marginBottom = "14px";
  const lastSessionLabel = createMetaLabel("Last Saved Session");
  const lastSessionText = document.createElement("p");
  lastSessionText.textContent = "No saved session yet.";
  lastSessionText.style.margin = "6px 0 0";
  lastSessionText.style.fontFamily = "ui-sans-serif, system-ui, sans-serif";
  lastSessionText.style.fontSize = "13px";
  lastSessionText.style.lineHeight = "1.5";
  lastSessionCard.append(lastSessionLabel, lastSessionText);
  const diagnosticsCard = createCard();
  diagnosticsCard.style.marginBottom = "14px";
  const diagnosticsLabel = createMetaLabel("Detection Status");
  const diagnosticsText = document.createElement("p");
  diagnosticsText.style.margin = "6px 0 0";
  diagnosticsText.style.fontFamily = "ui-sans-serif, system-ui, sans-serif";
  diagnosticsText.style.fontSize = "12px";
  diagnosticsText.style.lineHeight = "1.5";
  diagnosticsText.style.color = "#475467";
  diagnosticsText.textContent = buildDiagnosticsSummary(options.context, options.getEditorSnapshot());
  diagnosticsCard.append(diagnosticsLabel, diagnosticsText);
  const utilities = document.createElement("div");
  utilities.style.display = "grid";
  utilities.style.gridTemplateColumns = "1fr";
  utilities.style.gap = "8px";
  utilities.style.marginBottom = "14px";
  const resetButton = createButton("Reset Local Data", "secondary");
  utilities.append(resetButton);
  const status = document.createElement("p");
  status.textContent = "Ready to start.";
  status.style.margin = "14px 0 0";
  status.style.color = "#475467";
  status.style.fontFamily = "ui-sans-serif, system-ui, sans-serif";
  status.style.fontSize = "13px";
  let intervalId = null;
  let notesSaveTimer = null;
  let elapsedSeconds = 0;
  let sessionStartMs = null;
  let hintCount = 0;
  let reviewRequested = false;
  let interviewActive = false;
  let assistantConfigured = false;
  let distractionsHidden2 = false;
  let lastEditorSnapshot = null;
  let collapsed = false;
  let dragPointerId = null;
  let dragOffsetX = 0;
  let dragOffsetY = 0;
  void hydrate();
  header.addEventListener("pointerdown", (event) => {
    const target = event.target;
    if (target instanceof HTMLElement && target.closest("button, input, textarea")) {
      return;
    }
    const rect = root.getBoundingClientRect();
    dragPointerId = event.pointerId;
    dragOffsetX = event.clientX - rect.left;
    dragOffsetY = event.clientY - rect.top;
    root.style.right = "";
    root.style.left = `${rect.left}px`;
    root.style.top = `${rect.top}px`;
    root.style.bottom = "";
    root.style.transition = "none";
    header.style.cursor = "grabbing";
    header.setPointerCapture(event.pointerId);
    event.preventDefault();
  });
  header.addEventListener("pointermove", (event) => {
    if (dragPointerId !== event.pointerId) {
      return;
    }
    const width = root.offsetWidth;
    const height = root.offsetHeight;
    const maxLeft = Math.max(0, window.innerWidth - width);
    const maxTop = Math.max(0, window.innerHeight - height);
    const nextLeft = clamp(event.clientX - dragOffsetX, 0, maxLeft);
    const nextTop = clamp(event.clientY - dragOffsetY, 0, maxTop);
    root.style.left = `${nextLeft}px`;
    root.style.top = `${nextTop}px`;
  });
  header.addEventListener("pointerup", (event) => {
    if (dragPointerId !== event.pointerId) {
      return;
    }
    dragPointerId = null;
    header.style.cursor = "grab";
    header.releasePointerCapture(event.pointerId);
    root.style.transition = "width 180ms ease, padding 180ms ease";
  });
  header.addEventListener("pointercancel", (event) => {
    if (dragPointerId !== event.pointerId) {
      return;
    }
    dragPointerId = null;
    header.style.cursor = "grab";
    root.style.transition = "width 180ms ease, padding 180ms ease";
  });
  startButton.addEventListener("click", async () => {
    if (!interviewActive) {
      interviewActive = true;
      reviewRequested = false;
      hintCount = 0;
      elapsedSeconds = 0;
      sessionStartMs = Date.now();
      timer.textContent = "00:00";
      startButton.textContent = "End Session";
      modeValue.textContent = "On";
      distractionButton.disabled = false;
      hintButton.disabled = false;
      updateReviewButton();
      notes.disabled = false;
      hintText.textContent = "Hints will appear here.";
      followUp.textContent = "";
      reviewText.textContent = "No review yet.";
      status.textContent = assistantConfigured ? "Interview session started." : "Interview session started. Add your OpenAI API key below to enable hints and review.";
      startTimer();
      notes.focus();
      refreshHintProgress();
      renderCollapsedState();
      return;
    }
    await saveCurrentSession();
    endSession("Session ended and saved locally.");
    await refreshLastSession(lastSessionText);
    await refreshRecentSessions(recentSessionsList);
  });
  distractionButton.addEventListener("click", () => {
    if (!interviewActive) {
      status.textContent = "Start the interview before hiding distractions.";
      return;
    }
    const result = options.onDistractionToggle(!distractionsHidden2);
    distractionsHidden2 = result.hidden;
    distractionButton.textContent = distractionsHidden2 ? "Show Distractions" : "Hide Distractions";
    status.textContent = result.count > 0 ? `${distractionsHidden2 ? "Hidden" : "Restored"} ${result.count} distraction section${result.count === 1 ? "" : "s"}.` : "No known distraction sections found on this page.";
    renderCollapsedState();
  });
  hintButton.addEventListener("click", async () => {
    if (!interviewActive) {
      status.textContent = "Start the interview before requesting a hint.";
      return;
    }
    hintButton.disabled = true;
    status.textContent = "Generating hint...";
    hintText.textContent = "Generating hint...";
    followUp.textContent = "Preparing follow-up question...";
    try {
      const response = await options.onHintRequest({
        userAttempt: notes.value.trim(),
        hintLevel: hintCount + 1,
        onProgress(partialHint) {
          if (!partialHint.trim()) {
            return;
          }
          hintText.textContent = partialHint;
          followUp.textContent = "Preparing follow-up question...";
          status.textContent = "Streaming hint...";
        }
      });
      hintCount += 1;
      renderHint(response, hintText, followUp);
      status.textContent = `Hint ${hintCount} ready.`;
      refreshHintProgress();
      renderCollapsedState();
    } catch (error) {
      followUp.textContent = "";
      status.textContent = formatErrorMessage(error, "Hint request failed.");
      refreshHintProgress();
      renderCollapsedState();
    }
  });
  reviewButton.addEventListener("click", async () => {
    if (!interviewActive) {
      status.textContent = "Start the interview before requesting review.";
      return;
    }
    reviewButton.disabled = true;
    status.textContent = "Generating basic review...";
    try {
      const editorSnapshot = options.getEditorSnapshot();
      lastEditorSnapshot = editorSnapshot;
      const response = await options.onReviewRequest({
        approach: notes.value.trim(),
        code: editorSnapshot?.code ?? ""
      });
      renderReview(response, reviewText, editorSnapshot);
      reviewRequested = true;
      updateReviewButton();
      await saveCurrentSession();
      status.textContent = editorSnapshot ? `Basic review saved using ${formatEditorSource(editorSnapshot.source)}.` : "Basic review saved using notes only. Editor code was not detected.";
      await refreshLastSession(lastSessionText);
      await refreshRecentSessions(recentSessionsList);
      renderCollapsedState();
    } catch (error) {
      reviewButton.disabled = false;
      reviewText.textContent = formatErrorMessage(error, "Review request failed.");
      status.textContent = formatErrorMessage(error, "Review request failed.");
      renderCollapsedState();
    }
  });
  notes.addEventListener("input", () => {
    if (notesSaveTimer !== null) {
      window.clearTimeout(notesSaveTimer);
    }
    notesSaveTimer = window.setTimeout(() => {
      void options.onNotesChange(notes.value);
    }, 250);
  });
  resetButton.addEventListener("click", async () => {
    stopTimer();
    if (notesSaveTimer !== null) {
      window.clearTimeout(notesSaveTimer);
      notesSaveTimer = null;
    }
    if (distractionsHidden2) {
      options.onDistractionToggle(false);
    }
    interviewActive = false;
    sessionStartMs = null;
    elapsedSeconds = 0;
    hintCount = 0;
    reviewRequested = false;
    distractionsHidden2 = false;
    await options.onResetLocalData();
    notes.value = "";
    timer.textContent = "00:00";
    modeValue.textContent = "Off";
    startButton.textContent = "Start Interview";
    notes.disabled = true;
    hintButton.disabled = true;
    updateReviewButton();
    distractionButton.disabled = true;
    distractionButton.textContent = "Hide Distractions";
    hintText.textContent = "Start the session to unlock hints.";
    followUp.textContent = "";
    reviewText.textContent = "No review yet.";
    lastEditorSnapshot = null;
    status.textContent = "Local extension data cleared.";
    refreshHintProgress();
    await refreshLastSession(lastSessionText);
    await refreshRecentSessions(recentSessionsList);
    diagnosticsText.textContent = buildDiagnosticsSummary(options.context, options.getEditorSnapshot());
    renderCollapsedState();
  });
  saveSettingsButton.addEventListener("click", async () => {
    saveSettingsButton.disabled = true;
    testSettingsButton.disabled = true;
    clearSettingsButton.disabled = true;
    settingsStatus.textContent = "Saving OpenAI settings...";
    try {
      const summary = await options.onSaveAssistantSettings({
        apiKey: apiKeyInput.value,
        model: modelInput.value
      });
      apiKeyInput.value = "";
      applyAssistantSettings(summary, summary.hasApiKey ? "Settings saved." : "Add an API key to enable hints and review.");
      status.textContent = summary.hasApiKey ? "OpenAI settings saved. You can now request hints and review." : "OpenAI settings updated, but no API key is saved yet.";
    } catch (error) {
      settingsStatus.textContent = formatErrorMessage(error, "Failed to save OpenAI settings.");
    } finally {
      saveSettingsButton.disabled = false;
      testSettingsButton.disabled = false;
      clearSettingsButton.disabled = false;
    }
  });
  testSettingsButton.addEventListener("click", async () => {
    testSettingsButton.disabled = true;
    saveSettingsButton.disabled = true;
    clearSettingsButton.disabled = true;
    settingsStatus.textContent = "Testing OpenAI connection...";
    try {
      const result = await options.onTestAssistantConnection();
      settingsStatus.textContent = result.message;
      modelInput.value = result.model;
      status.textContent = result.ok ? `OpenAI ready with ${result.model}.` : result.message;
    } catch (error) {
      settingsStatus.textContent = formatErrorMessage(error, "OpenAI connection test failed.");
    } finally {
      testSettingsButton.disabled = false;
      saveSettingsButton.disabled = false;
      clearSettingsButton.disabled = false;
    }
  });
  clearSettingsButton.addEventListener("click", async () => {
    clearSettingsButton.disabled = true;
    saveSettingsButton.disabled = true;
    testSettingsButton.disabled = true;
    settingsStatus.textContent = "Clearing saved API key...";
    try {
      const summary = await options.onClearAssistantSettings();
      apiKeyInput.value = "";
      applyAssistantSettings(summary, "Saved API key cleared.");
      status.textContent = "OpenAI key cleared from this Chrome profile.";
    } catch (error) {
      settingsStatus.textContent = formatErrorMessage(error, "Failed to clear OpenAI settings.");
    } finally {
      clearSettingsButton.disabled = false;
      saveSettingsButton.disabled = false;
      testSettingsButton.disabled = false;
    }
  });
  collapseButton.addEventListener("click", () => {
    collapsed = !collapsed;
    applyCollapsedLayout();
  });
  body.append(
    modeCard,
    controls,
    settingsCard,
    timerCard,
    hintUsageCard,
    notesLabel,
    notes,
    notesMeta,
    actions,
    hintCard,
    reviewCard,
    recentSessionsCard,
    lastSessionCard,
    diagnosticsCard,
    utilities,
    status
  );
  root.append(header, collapsedSummary, body);
  container.append(root);
  return {
    async destroy() {
      if (interviewActive) {
        await saveCurrentSession();
      }
      if (notesSaveTimer !== null) {
        window.clearTimeout(notesSaveTimer);
        notesSaveTimer = null;
      }
      if (distractionsHidden2) {
        options.onDistractionToggle(false);
      }
      header.style.cursor = "grab";
      stopTimer();
      root.remove();
    }
  };
  async function hydrate() {
    const [savedNotes, assistantSettings] = await Promise.all([
      options.loadNotes(),
      options.loadAssistantSettings(),
      refreshLastSession(lastSessionText),
      refreshRecentSessions(recentSessionsList)
    ]);
    notes.value = savedNotes;
    applyAssistantSettings(assistantSettings);
    refreshHintProgress();
    diagnosticsText.textContent = buildDiagnosticsSummary(options.context, options.getEditorSnapshot());
    renderCollapsedState();
    applyCollapsedLayout();
  }
  function applyAssistantSettings(summary, message) {
    assistantConfigured = summary.hasApiKey;
    modelInput.value = summary.model;
    apiKeyInput.placeholder = summary.hasApiKey ? `Saved key: ${summary.apiKeyLabel ?? "Saved"}` : "Paste your OpenAI API key";
    settingsSummary.textContent = summary.hasApiKey ? `Using ${summary.model} with ${summary.apiKeyLabel ?? "a saved key"}.` : "No API key saved yet.";
    settingsStatus.textContent = message ?? (summary.hasApiKey ? "Hints and review are ready to use." : "Save your API key to enable hints and review.");
    updateHintButton();
    updateReviewButton();
  }
  function refreshHintProgress() {
    const nextLevel = hintCount + 1;
    hintUsageValue.textContent = hintCount === 0 ? "No hints used yet. Next hint: Level 1." : `${hintCount} used. Next hint: ${formatHintLevel(nextLevel)}.`;
    hintUsageMeta.textContent = assistantConfigured ? "Hints are unlimited. Level 1 nudges, Level 2 patterns, Level 3+ stronger direction." : "Add your OpenAI API key below to unlock unlimited hints and review.";
    updateHintButton();
    renderCollapsedState();
  }
  async function refreshLastSession(target) {
    const lastSession = await options.loadLastSessionSummary();
    if (!lastSession) {
      target.textContent = "No saved session yet.";
      return;
    }
    target.textContent = formatSessionSummary(lastSession);
  }
  async function refreshRecentSessions(target) {
    const history = await options.loadSessionHistory();
    target.replaceChildren();
    if (history.length === 0) {
      const empty = document.createElement("p");
      empty.textContent = "No recent sessions saved yet.";
      empty.style.margin = "0";
      empty.style.fontFamily = "ui-sans-serif, system-ui, sans-serif";
      empty.style.fontSize = "13px";
      empty.style.lineHeight = "1.5";
      empty.style.color = "#667085";
      target.append(empty);
      return;
    }
    for (const session of history.slice(0, 4)) {
      const item = document.createElement("p");
      item.textContent = formatSessionSummary(session);
      item.style.margin = "0 0 10px";
      item.style.fontFamily = "ui-sans-serif, system-ui, sans-serif";
      item.style.fontSize = "12px";
      item.style.lineHeight = "1.5";
      item.style.color = "#475467";
      target.append(item);
    }
  }
  async function saveCurrentSession() {
    const summary = buildSessionSummary();
    await options.onSessionComplete(summary);
  }
  function buildSessionSummary() {
    const startedAt = sessionStartMs ? new Date(sessionStartMs).toISOString() : (/* @__PURE__ */ new Date()).toISOString();
    const endedAt = (/* @__PURE__ */ new Date()).toISOString();
    const durationSeconds = sessionStartMs ? Math.max(0, Math.floor((Date.now() - sessionStartMs) / 1e3)) : elapsedSeconds;
    return {
      problemUrl: options.context.problemUrl,
      problemTitle: options.context.problemTitle,
      difficulty: options.context.difficulty,
      startedAt,
      endedAt,
      durationSeconds,
      modeEnabled: interviewActive,
      hintCount,
      reviewRequested,
      notesPreview: notes.value.trim().slice(0, 140)
    };
  }
  function startTimer() {
    stopTimer();
    intervalId = window.setInterval(() => {
      if (!sessionStartMs) {
        return;
      }
      elapsedSeconds = Math.max(0, Math.floor((Date.now() - sessionStartMs) / 1e3));
      timer.textContent = formatElapsed(elapsedSeconds);
      renderCollapsedState();
    }, 1e3);
  }
  function stopTimer() {
    if (intervalId !== null) {
      window.clearInterval(intervalId);
      intervalId = null;
    }
  }
  function endSession(message) {
    interviewActive = false;
    stopTimer();
    sessionStartMs = null;
    startButton.textContent = "Start Interview";
    modeValue.textContent = "Off";
    notes.disabled = true;
    lastEditorSnapshot = null;
    hintButton.disabled = true;
    updateReviewButton();
    distractionButton.disabled = true;
    if (distractionsHidden2) {
      options.onDistractionToggle(false);
      distractionsHidden2 = false;
      distractionButton.textContent = "Hide Distractions";
    }
    status.textContent = message;
    renderCollapsedState();
  }
  function updateHintButton() {
    hintButton.textContent = assistantConfigured ? `Get ${formatHintLevel(hintCount + 1)} Hint` : "Add API Key for Hints";
    hintButton.disabled = !(interviewActive && assistantConfigured);
  }
  function updateReviewButton() {
    if (!interviewActive) {
      reviewButton.textContent = "Review My Attempt";
      reviewButton.disabled = true;
      return;
    }
    reviewButton.textContent = assistantConfigured ? reviewRequested ? "Review My Attempt Again" : "Review My Attempt" : "Add API Key for Review";
    reviewButton.disabled = !assistantConfigured;
  }
  function applyCollapsedLayout() {
    body.style.display = collapsed ? "none" : "";
    collapsedSummary.style.display = collapsed ? "" : "none";
    titleGroup.style.display = collapsed ? "none" : "";
    title.style.fontSize = collapsed ? "18px" : "28px";
    collapseButton.textContent = collapsed ? "Expand" : "Collapse";
    collapseButton.style.minWidth = collapsed ? "72px" : "90px";
    header.style.marginBottom = collapsed ? "10px" : "14px";
    root.style.width = collapsed ? "170px" : "360px";
    root.style.padding = collapsed ? "14px" : "18px";
    renderCollapsedState();
  }
  function renderCollapsedState() {
    collapsedModeValue.textContent = interviewActive ? "Interview Active" : "Ready";
    collapsedTimer.textContent = timer.textContent;
    collapsedHints.textContent = interviewActive ? `${hintCount} hint${hintCount === 1 ? "" : "s"} used this session${reviewRequested ? " \u2022 reviewed" : ""}` : reviewRequested ? "Last action: review saved" : "Panel collapsed";
  }
}
function formatElapsed(totalSeconds) {
  const minutes = String(Math.floor(totalSeconds / 60)).padStart(2, "0");
  const seconds = String(totalSeconds % 60).padStart(2, "0");
  return `${minutes}:${seconds}`;
}
function clamp(value, min, max) {
  return Math.min(Math.max(value, min), max);
}
function formatHintLevel(level) {
  if (level <= 1) {
    return "Level 1";
  }
  if (level === 2) {
    return "Level 2";
  }
  return "Level 3+";
}
function createButton(label, variant) {
  const button = document.createElement("button");
  button.type = "button";
  button.textContent = label;
  button.style.borderRadius = "999px";
  button.style.padding = "12px 14px";
  button.style.border = variant === "primary" ? "none" : "1px solid #d0d5dd";
  button.style.cursor = "pointer";
  button.style.fontFamily = "ui-sans-serif, system-ui, sans-serif";
  button.style.fontWeight = "600";
  button.style.fontSize = "13px";
  button.style.background = variant === "primary" ? "#111827" : "rgba(255, 255, 255, 0.9)";
  button.style.color = variant === "primary" ? "#f9fafb" : "#1f2937";
  return button;
}
function createTextInput(type, placeholder) {
  const input = document.createElement("input");
  input.type = type;
  input.placeholder = placeholder;
  input.style.width = "100%";
  input.style.boxSizing = "border-box";
  input.style.border = "1px solid #d0d5dd";
  input.style.borderRadius = "12px";
  input.style.padding = "10px 12px";
  input.style.fontFamily = "ui-sans-serif, system-ui, sans-serif";
  input.style.fontSize = "13px";
  input.style.background = "rgba(255, 255, 255, 0.9)";
  input.style.color = "#1f2937";
  return input;
}
function createCard() {
  const card = document.createElement("div");
  card.style.borderRadius = "16px";
  card.style.padding = "12px 14px";
  card.style.background = "rgba(255, 255, 255, 0.72)";
  card.style.border = "1px solid rgba(208, 213, 221, 0.9)";
  return card;
}
function createMetaLabel(text) {
  const label = document.createElement("p");
  label.textContent = text.toUpperCase();
  label.style.margin = "0";
  label.style.fontSize = "10px";
  label.style.letterSpacing = "0.14em";
  label.style.fontWeight = "700";
  label.style.fontFamily = "ui-sans-serif, system-ui, sans-serif";
  label.style.color = "#9a6700";
  return label;
}
function renderHint(response, hintText, followUp) {
  hintText.textContent = response.hint;
  followUp.textContent = response.followUpQuestion;
}
function renderReview(response, reviewText, editorSnapshot) {
  const reviewSource = editorSnapshot ? `Notes plus code from ${escapeHtml(formatEditorSource(editorSnapshot.source))}` : "Notes only. Editor code was not detected.";
  reviewText.innerHTML = [
    `<strong>Source:</strong> ${reviewSource}`,
    `<strong>Clarity:</strong> ${escapeHtml(response.clarityFeedback)}`,
    `<strong>Time:</strong> ${escapeHtml(response.timeComplexity)}`,
    `<strong>Space:</strong> ${escapeHtml(response.spaceComplexity)}`,
    `<strong>Improve:</strong> ${escapeHtml(response.improvementSuggestion)}`
  ].join("<br /><br />");
}
function formatSessionSummary(summary) {
  const duration = formatElapsed(summary.durationSeconds ?? 0);
  const difficulty = summary.difficulty ? ` \u2022 ${summary.difficulty}` : "";
  const reviewState = summary.reviewRequested ? "reviewed" : "not reviewed";
  return `${summary.problemTitle}${difficulty} \u2022 ${duration} \u2022 ${summary.hintCount} hint${summary.hintCount === 1 ? "" : "s"} \u2022 ${reviewState}`;
}
function buildDiagnosticsSummary(context, editorSnapshot) {
  const difficulty = context.difficulty ?? "Unknown difficulty";
  const url = new URL(context.problemUrl);
  const editorStatus = editorSnapshot ? `Editor detected via ${formatEditorSource(editorSnapshot.source)}.` : "Editor code not detected yet.";
  return `Detected ${difficulty}. Tracking notes and session data locally for ${url.pathname}. ${editorStatus}`;
}
function formatEditorSource(source) {
  switch (source) {
    case "monaco-model":
      return "Monaco model";
    case "textarea":
      return "editor textarea";
    case "code-block":
      return "editor code block";
    case "visible-lines":
      return "visible editor lines";
    default:
      return "editor fallback";
  }
}
function formatErrorMessage(error, fallback) {
  if (error instanceof Error && error.message) {
    return error.message;
  }
  return fallback;
}
function escapeHtml(value) {
  return value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;");
}

// src/content/index.ts
var PANEL_ID = "leetcode-interviewer-root";
var REAPPLY_DELAY_MS = 150;
var mountedPanel = null;
var reapplyTimer = null;
var distractionsHidden = false;
bootstrap();
function bootstrap() {
  observeNavigation();
  observeDom();
  void syncPanel();
}
function observeNavigation() {
  const { pushState, replaceState } = window.history;
  const dispatch = () => window.dispatchEvent(new Event("leetcode-interviewer:navigation"));
  window.history.pushState = function pushStatePatched(...args) {
    pushState.apply(this, args);
    dispatch();
  };
  window.history.replaceState = function replaceStatePatched(...args) {
    replaceState.apply(this, args);
    dispatch();
  };
  window.addEventListener("popstate", dispatch);
  window.addEventListener("leetcode-interviewer:navigation", () => {
    distractionsHidden = false;
    void syncPanel();
  });
}
function observeDom() {
  const observer = new MutationObserver(() => {
    if (reapplyTimer !== null) {
      window.clearTimeout(reapplyTimer);
    }
    reapplyTimer = window.setTimeout(() => {
      if (distractionsHidden) {
        setDistractionSectionsHidden(document, true);
      }
      void syncPanel();
    }, REAPPLY_DELAY_MS);
  });
  observer.observe(document.documentElement, {
    childList: true,
    subtree: true
  });
  window.addEventListener(
    "beforeunload",
    () => {
      observer.disconnect();
    },
    { once: true }
  );
}
async function syncPanel() {
  const url = new URL(window.location.href);
  if (!isSupportedProblemPage(url)) {
    await unmountPanel();
    return;
  }
  const context = extractProblemContext(document, url);
  if (!context) {
    return;
  }
  if (mountedPanel?.problemUrl === context.problemUrl) {
    return;
  }
  await unmountPanel();
  const host = document.createElement("div");
  host.id = PANEL_ID;
  document.body.append(host);
  const controller = createInterviewPanel(host, {
    context,
    loadAssistantSettings,
    loadLastSessionSummary,
    loadSessionHistory,
    loadNotes() {
      return loadProblemNotes(context.problemUrl);
    },
    getEditorSnapshot() {
      return extractEditorSnapshot(document, window);
    },
    onDistractionToggle(hidden) {
      distractionsHidden = hidden;
      return setDistractionSectionsHidden(document, hidden);
    },
    onClearAssistantSettings: clearAssistantSettings,
    onHintRequest(input) {
      return requestHint(
        {
          userAttempt: input.userAttempt,
          hintLevel: input.hintLevel,
          problemTitle: context.problemTitle,
          problemDescription: context.problemDescription
        },
        input.onProgress
      );
    },
    onReviewRequest(input) {
      return requestReview({
        ...input,
        problemTitle: context.problemTitle
      });
    },
    onNotesChange(notes) {
      return saveProblemNotes(context.problemUrl, notes);
    },
    onResetLocalData: clearLocalData,
    onSessionComplete: saveSessionSummary,
    onSaveAssistantSettings: saveAssistantSettings,
    onTestAssistantConnection: testAssistantConnection
  });
  mountedPanel = {
    problemUrl: context.problemUrl,
    destroy: controller.destroy
  };
}
async function unmountPanel() {
  if (!mountedPanel) {
    const existing = document.getElementById(PANEL_ID);
    existing?.remove();
    return;
  }
  const current = mountedPanel;
  mountedPanel = null;
  await current.destroy();
}
//# sourceMappingURL=index.js.map
